'use strict';

(function () {
  beforeAll(function () {
    angular.element(document.querySelector('head')).append('<base href="/">');
  });
}());
